/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: triu.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 15-Jul-2020 15:07:30
 */

#ifndef TRIU_H
#define TRIU_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "cubicRegScript_types.h"

/* Function Declarations */
extern void b_triu(emxArray_real_T *x);
extern void triu(emxArray_real_T *x);

#endif

/*
 * File trailer for triu.h
 *
 * [EOF]
 */
