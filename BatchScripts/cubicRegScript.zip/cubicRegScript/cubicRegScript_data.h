/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: cubicRegScript_data.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 15-Jul-2020 15:07:30
 */

#ifndef CUBICREGSCRIPT_DATA_H
#define CUBICREGSCRIPT_DATA_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "cubicRegScript_types.h"

/* Variable Declarations */
extern unsigned int state[625];
extern FILE * eml_openfiles[20];
extern boolean_T eml_autoflush[20];

#endif

/*
 * File trailer for cubicRegScript_data.h
 *
 * [EOF]
 */
