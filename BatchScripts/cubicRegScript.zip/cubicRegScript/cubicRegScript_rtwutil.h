/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: cubicRegScript_rtwutil.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 15-Jul-2020 15:07:30
 */

#ifndef CUBICREGSCRIPT_RTWUTIL_H
#define CUBICREGSCRIPT_RTWUTIL_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "cubicRegScript_types.h"

/* Function Declarations */
extern double rt_hypotd_snf(double u0, double u1);
extern double rt_roundd_snf(double u);

#endif

/*
 * File trailer for cubicRegScript_rtwutil.h
 *
 * [EOF]
 */
