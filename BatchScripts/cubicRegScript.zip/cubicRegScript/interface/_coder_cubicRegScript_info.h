/* 
 * Academic License - for use in teaching, academic research, and meeting 
 * course requirements at degree granting institutions only.  Not for 
 * government, commercial, or other organizational use. 
 * File: _coder_cubicRegScript_info.h 
 *  
 * MATLAB Coder version            : 4.1 
 * C/C++ source code generated on  : 15-Jul-2020 15:07:30 
 */

#ifndef _CODER_CUBICREGSCRIPT_INFO_H
#define _CODER_CUBICREGSCRIPT_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#endif
/* 
 * File trailer for _coder_cubicRegScript_info.h 
 *  
 * [EOF] 
 */
