/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: cubicRegScript_data.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 15-Jul-2020 15:07:30
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "cubicRegScript.h"
#include "cubicRegScript_data.h"

/* Variable Definitions */
unsigned int state[625];
FILE * eml_openfiles[20];
boolean_T eml_autoflush[20];

/*
 * File trailer for cubicRegScript_data.c
 *
 * [EOF]
 */
