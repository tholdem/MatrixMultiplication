/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: fwrite.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 15-Jul-2020 15:07:30
 */

#ifndef FWRITE_H
#define FWRITE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "cubicRegScript_types.h"

/* Type Definitions */

/* Function Declarations */
extern void b_fwrite(double fileID, const emxArray_real_T *x);

#endif

/*
 * File trailer for fwrite.h
 *
 * [EOF]
 */
